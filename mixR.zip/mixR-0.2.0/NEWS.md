
## 0.2.0

- Updated the function plot.mixfitEM()
- Updated the function density.mixfitEM()
- Corrected the function to_k_lambda_weibull()
- Solved the NA issue in the output of mixfit() (NaN still happens when EM algorithm fails to converge)
- Added a vignette
- Added tests

## 0.1.1

- Resolved the warnings issues found in [check results](https://www.r-project.org/nosvn/R.check/r-release-windows-ix86+x86_64/mixR-00check.html).


## 0.1.0

- First version
