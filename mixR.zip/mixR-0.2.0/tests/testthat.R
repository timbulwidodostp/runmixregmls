library(testthat)
library(mixR)

test_check("mixR")
