## Test environments
* local OS X installation, R 4.0.5
* ubuntu 16.04 (on travis-ci), R 4.0.5
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 note


