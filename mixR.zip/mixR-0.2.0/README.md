R package for fitting finite mixture models for both raw and binned data
========================================================================

Installation
------------

For stable/pre-compiled(for Windows and OS X) version, please install from [CRAN](https://CRAN.R-project.org/package=mixR):

```r
install.packages('mixR')
```

Examples
--------
Please check the vignette.
